/** Automatically generated file. DO NOT MODIFY */
package coursera.artem.modernartui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}